package FelipeMoraisHello;
import java.util.Calendar;
public class HelloWorld {
	Calendar c = Calendar.getInstance();
    private String nome;
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }
    public void imprimir() {
        System.out.println(c.get(Calendar.HOUR_OF_DAY)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND)+" Ol� " + this.getNome() + ". Voc� acabou de fazer seu primeiro Hello World em Java. Parab�ns.");
    }
}

