package FelipeMoraisHello;
public class Application {
    public static void main(String[] args) {
    	HelloWorld helloWorld = new HelloWorld();
        helloWorld.setNome("Felipe");
        helloWorld.imprimir();
        HelloWorld helloWorld1 = new HelloWorld();
        helloWorld1.setNome("Gabriel");
        helloWorld1.imprimir();
        HelloWorld helloWorld2 = new HelloWorld();
        helloWorld2.setNome("Ana");
        helloWorld2.imprimir();
        HelloWorld helloWorld11 = new HelloWorld();
        helloWorld11.setNome(null);
        helloWorld11.imprimir();

    }
}

