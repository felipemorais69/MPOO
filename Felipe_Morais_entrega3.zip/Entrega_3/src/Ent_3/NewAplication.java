package Ent_3;

public class NewAplication {
		public static void main(String[] args) {
			Funcionario felipe= new Funcionario();
			felipe.setNome("Felipe");
			felipe.setSalario(6000);
			felipe.aumento(20);
			felipe.imprimir();
	        Funcionario ze = new Gerente();
	        ze.setNome("Z�");
	        ze.setSalario (1000);
	        ze.setLista("L_it");
	        ze.setLista("MPOO PROJECT");
	        ze.aumento();
	        ze.imprimir();
	        Funcionario maria = new Secretaria();
	        maria.setNome ("Maria");
	        maria.setSalario (2000);
	        maria.setLista("ingles");
	        maria.setLista("Portugues");
	        maria.aumento(5);
	        maria.imprimir();
	        Funcionario roberto = new Programador();
	        roberto.setNome("Roberto");
	        roberto.setSalario(2500);
	        roberto.aumento();
	        roberto.setLista("JAVA");
	        roberto.setLista("PYTHON");
	        roberto.imprimir();
	        
	   
	   }

}
