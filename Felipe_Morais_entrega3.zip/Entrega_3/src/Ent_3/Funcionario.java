package Ent_3;

import java.util.ArrayList;
import java.util.List;

public class Funcionario {
	private String nome;
	private double salario;
	private double custo = 1.8;
	private List<String> lista = new ArrayList<String>();


	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public final void setSalario(double salario) {
        this.salario = salario;
        this.custo = salario * getPercentualCusto();
    }
	
	protected double getPercentualCusto() {
		return 1.8;
	}
	public double getCusto() {
		return custo;
	}
	public List<String> getLista() {
		return lista;
		
	}
	public void setLista(String string) {
		this.lista.add(string);
	}
	
	public void imprimir() { 
        System.out.println(this.getNome() + " ganha " +
          this.getSalario() + " e tem um custo de " +
          this.getCusto() );
    }
	
	public void aumento(){
		setSalario(getSalario()+0.1*getSalario());
	}
	public void aumento(double taxa){
		if(taxa<1){
			setSalario(getSalario()+taxa*getSalario());
		}else{
			setSalario(getSalario()+(taxa/100)*getSalario());
		}
	}
	
	
}
