package Ent_3;




public class Gerente extends Funcionario {
    protected double getPercentualCusto() {
        return 1.0;
    }
	
	
	public void imprimir(){
		   super.imprimir() ;
		   System.out.println("Gerencia os seguintes projetos " + super.getLista());
		   
	   }
}

