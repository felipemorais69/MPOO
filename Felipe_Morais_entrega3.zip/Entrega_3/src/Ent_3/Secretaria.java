package Ent_3;



public class Secretaria extends Funcionario {

	public void imprimir(){
		   super.imprimir() ;
		   System.out.println("� fluente nos seguintes idiomas "+super.getLista());
		   
	   }
}