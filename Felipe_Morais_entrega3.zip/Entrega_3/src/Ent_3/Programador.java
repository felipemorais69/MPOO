package Ent_3;



public class Programador extends Funcionario {

	public void imprimir(){
		   super.imprimir() ;
		   System.out.println("Conhece as seguintes linguagens "+super.getLista());
		   
	   }
}
