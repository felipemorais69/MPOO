package Counter;

public class Funcionario {
	private String nome;
	private double salario;
	private double custo;
	private static int counter;
	
	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public double getCusto() {
		return custo;
	}


	public void setCusto(double custo) {
		this.custo = custo;
	}


	public static int getCounter() {
		return counter;
	}

	public static void imprimir(){
		 System.out.println(Funcionario.getCounter());
	}
	
	public void setCounter(int count) {
		Funcionario.counter = count;
	}
	public Funcionario(){
		counter++;
	}
	


}
