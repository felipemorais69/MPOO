package Counter;

public class FuncionarioAplicacion {
    public static void main(String[] args) {
         Funcionario ze = new Funcionario();
         ze.setNome("Z�");
         ze.setSalario (1000);
         ze.setCusto (1300);
         System.out.println(ze.getNome() + " ganha " +
           ze.getSalario() + " e tem um custo de " +
           ze.getCusto() );
         Funcionario joao = new Funcionario();
         joao.setNome ("Jo�o");
         joao.setSalario (2000);
         joao.setCusto (2600);
         System.out.println(joao.getNome() + " ganha " +
           joao.getSalario() + " e tem um custo de " +
           joao.getCusto() );
         Funcionario.imprimir();
    } 
}

