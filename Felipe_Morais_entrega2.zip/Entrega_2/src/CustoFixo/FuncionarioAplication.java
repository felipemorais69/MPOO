package CustoFixo;

public class FuncionarioAplication {
    public static void main(String[] args) {
         Funcionario ze = new Funcionario();
         ze.setNome("Z�");
         ze.setSalario (1000);
         ze.imprimir();
         Funcionario joao = new Funcionario();
         joao.setNome ("Jo�o");
         joao.setSalario (2000);
         joao.imprimir();
    
    }
   
}

