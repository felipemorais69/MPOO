package CustoFixo;

public class Funcionario {
	private String nome;
	private double salario;
	private double custo = 1.8;

	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public double getCusto() {
		return custo*this.salario;
	}
	
	
	public void imprimir() { 
        System.out.println(this.getNome() + " ganha " +
          this.getSalario() + " e tem um custo de " +
          this.getCusto() );
    }
	
}