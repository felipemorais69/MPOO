package Heran�aFuncionario;

public class NewAplication {
		public static void main(String[] args) {
	        Funcionario ze = new Funcionario();
	        ze.setNome("Z�");
	        ze.setSalario (1000);
	        ze.imprimir();
	        Funcionario joao = new Funcionario();
	        joao.setNome ("Jo�o");
	        joao.setSalario (2000);
	        joao.imprimir();
	        Programador roberto = new Programador();
	        roberto.setNome("Roberto");
	        roberto.setSalario(2500);
	        roberto.imprimir();
	        System.out.println(roberto.getLista());
	   
	   }

}
