package Heran�aFuncionario;

import java.util.ArrayList;
import java.util.List;

public class Programador extends Funcionario {
	
	private List<String> lista = new ArrayList<String>();
	
	public String getLista() {
		return (" e programa em " + lista);
	}
	public void setLista(List<String> lista) {
		this.lista = lista;
	}
}
