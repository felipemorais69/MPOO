package Heran�aFuncionario;

import java.util.ArrayList;
import java.util.List;

public class Gerente extends Funcionario {
	private List<String> lista = new ArrayList<String>();
	
	public String getLista() {
		return (" e comanda os seguintes projetos " + lista);
	}
	public void setLista(List<String> lista) {
		this.lista = lista;
	}

}

