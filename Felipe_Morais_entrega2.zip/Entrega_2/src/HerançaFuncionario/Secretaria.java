package Heran�aFuncionario;

import java.util.ArrayList;
import java.util.List;

public class Secretaria extends Funcionario {
	private List<String> lista = new ArrayList<String>();
	
	public String getLista() {
		return (" e fala os seguintes idiomas" + lista);
	}
	public void setLista(List<String> lista) {
		this.lista = lista;
	}
   
}